"""Constants for the Sengled Integration."""

DOMAIN = "sengledapi"
CONF_COUNTRY = "country"
CONF_TYPE = "wifi"
ATTRIBUTION = "Data provided by Sengled"
