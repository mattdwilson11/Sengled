HTTPS = "https://"
SET_ONOFF = "-elements.cloud.sengled.com/zigbee/device/deviceSetOnOff.json"
SET_BRIGHTNESS = "-elements.cloud.sengled.com/zigbee/device/deviceSetBrightness.json"
GET_DETAILS = "-element.cloud.sengled.com/zigbee/device/getDeviceDetails.json"
SET_GROUP = "-elements.cloud.sengled.com/zigbee/device/deviceSetGroup.json"
SET_COLOR_TEMPERATURE = (
    "-elements.cloud.sengled.com/zigbee/device/deviceSetColorTemperature.json"
)
GET_WIFI_DETAILS = "life2.cloud.sengled.com/life2/device/list.json"
